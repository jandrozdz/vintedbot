const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Data storage (in-memory for simplicity, use database in production)
let data = {
  announcements: [],
  games: [],
  standings: [],
  team: {
    name: 'LKS Różyca',
    description: 'Lokalny Klub Sportowy Różyca'
  }
};

// Load data from file if exists
const dataFile = path.join(__dirname, 'data.json');
if (fs.existsSync(dataFile)) {
  data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
}

// Save data to file
function saveData() {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

// Routes - Public
app.get('/', (req, res) => {
  res.render('index', { announcements: data.announcements, games: data.games });
});

app.get('/tabela', (req, res) => {
  res.render('standings', { standings: data.standings });
});

app.get('/mecze', (req, res) => {
  res.render('games', { games: data.games });
});

app.get('/historia', (req, res) => {
  res.render('history', { team: data.team });
});

app.get('/o-nas', (req, res) => {
  res.render('about', { team: data.team });
});

// Routes - Admin
app.get('/admin', (req, res) => {
  res.render('admin/dashboard', { 
    announcements: data.announcements,
    games: data.games,
    standings: data.standings
  });
});

app.get('/admin/announcements', (req, res) => {
  res.render('admin/announcements', { announcements: data.announcements });
});

app.post('/admin/announcements/add', (req, res) => {
  const { title, content, date } = req.body;
  const announcement = {
    id: Date.now(),
    title,
    content,
    date: date || new Date().toISOString().split('T')[0]
  };
  data.announcements.unshift(announcement);
  saveData();
  res.json({ success: true, announcement });
});

app.delete('/admin/announcements/:id', (req, res) => {
  data.announcements = data.announcements.filter(a => a.id != req.params.id);
  saveData();
  res.json({ success: true });
});

app.get('/admin/games', (req, res) => {
  res.render('admin/games', { games: data.games });
});

app.post('/admin/games/add', (req, res) => {
  const { homeTeam, awayTeam, date, time, score, status } = req.body;
  const game = {
    id: Date.now(),
    homeTeam,
    awayTeam,
    date,
    time,
    score: score || '- : -',
    status: status || 'scheduled'
  };
  data.games.push(game);
  saveData();
  res.json({ success: true, game });
});

app.delete('/admin/games/:id', (req, res) => {
  data.games = data.games.filter(g => g.id != req.params.id);
  saveData();
  res.json({ success: true });
});

app.get('/admin/standings', (req, res) => {
  res.render('admin/standings', { standings: data.standings });
});

app.post('/admin/standings/add', (req, res) => {
  const { position, team, matches, wins, draws, losses, points } = req.body;
  const standing = {
    id: Date.now(),
    position: parseInt(position),
    team,
    matches: parseInt(matches),
    wins: parseInt(wins),
    draws: parseInt(draws),
    losses: parseInt(losses),
    points: parseInt(points)
  };
  data.standings.push(standing);
  saveData();
  res.json({ success: true, standing });
});

app.delete('/admin/standings/:id', (req, res) => {
  data.standings = data.standings.filter(s => s.id != req.params.id);
  saveData();
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`LKS Różyca server running at http://localhost:${PORT}`);
});
