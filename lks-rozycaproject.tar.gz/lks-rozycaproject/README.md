# LKS Różyca Website

A Node.js-based website for LKS Różyca football club with public pages and admin panel.

## Features

- **Public Pages**: Home, Games, Standings, History, About
- **Admin Panel**: Manage announcements, games, and standings
- **Light Mode**: Modern, clean interface with blue/red/green accents
- **Data Persistence**: All data saved to `data.json`
- **No Dependencies**: No database required for basic setup

## Installation

1. Clone or navigate to the project directory
2. Install dependencies:
   ```bash
   npm install
   ```

## Running the Server

Start the server:
```bash
npm start
```

The site will be available at `http://localhost:3000`

## Pages

### Public
- `/` - Home with announcements and upcoming games
- `/mecze` - Games schedule and results
- `/tabela` - League standings table
- `/historia` - Club history
- `/o-nas` - About the club

### Admin
- `/admin` - Admin dashboard
- `/admin/announcements` - Manage announcements
- `/admin/games` - Manage games
- `/admin/standings` - Manage league standings

## Adding Content

### Announcements
1. Go to `/admin/announcements`
2. Fill in title, content, and date
3. Click "Dodaj Aktualność" (Add Announcement)

### Games
1. Go to `/admin/games`
2. Enter team names, date, time, score, and status
3. Click "Dodaj Mecz" (Add Game)

### Standings
1. Go to `/admin/standings`
2. Enter position, team name, and statistics
3. Click "Dodaj Drużynę" (Add Team)

## File Structure

```
lks-rozycaproject/
├── server.js              # Express server
├── package.json           # Dependencies
├── data.json             # Database (auto-generated)
├── README.md             # This file
├── public/
│   ├── css/
│   │   └── style.css    # Light mode styling
│   └── js/
│       └── main.js      # Client-side script
└── views/
    ├── index.ejs        # Home
    ├── games.ejs        # Games
    ├── standings.ejs    # Standings
    ├── history.ejs      # History
    ├── about.ejs        # About
    ├── layout.ejs       # Layout template
    └── admin/
        ├── dashboard.ejs      # Admin home
        ├── announcements.ejs  # Announcements management
        ├── games.ejs          # Games management
        └── standings.ejs      # Standings management
```

## Customization

### Colors
Edit the CSS variables in `public/css/style.css`:
- `--primary-blue`: Main blue color
- `--accent-red`: Red accent
- `--accent-green`: Green accent

### Team Name
Change "LKS RÓŻYCA" in the header files (server.js, views files)

### Adding Custom Icons
Replace emoji references in templates with `<img>` tags pointing to your icon files in `public/`.

## Deployment

To deploy on a host like Heroku, Railway, or similar:

1. Set environment variable for PORT if needed
2. Push code to hosting provider
3. Run `npm install && npm start`

The app uses in-memory data with file persistence, so each server restart will load the last saved state from `data.json`.

## Notes

- No authentication on admin panel. Implement auth before using in production
- Data is stored in `data.json` - back this up regularly
- For production, consider using a proper database like MongoDB or PostgreSQL

---

Built with Express.js and EJS templating.
